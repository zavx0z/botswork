import enum


class DialogType(enum.Enum):
    support = 'support'
    private = 'private'
